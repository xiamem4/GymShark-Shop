<?php

return [
    'Names' => [
        'AED' => [
            'AED',
            'Ndiriha wa Lemila alabu',
        ],
        'AOA' => [
            'AOA',
            'Kwanza wa Angola',
        ],
        'AUD' => [
            'A$',
            'Ndola wa Ositali',
        ],
        'BHD' => [
            'BHD',
            'Ndina wa Bahrene',
        ],
        'BIF' => [
            'BIF',
            'Nfalanga wa Bulundi',
        ],
        'BWP' => [
            'BWP',
            'Pula wa Botswana',
        ],
        'CAD' => [
            'CA$',
            'Ndola wa Kanada',
        ],
        'CDF' => [
            'FC',
            'Nfalanga wa Kongu',
        ],
        'CHF' => [
            'CHF',
            'Nfalanga wa Swise',
        ],
        'CNY' => [
            'CN¥',
            'Yuani Renminbi wa Shine',
        ],
        'CVE' => [
            'CVE',
            'Esikuludo wa Kapevere',
        ],
        'DJF' => [
            'DJF',
            'Nfalanga wa Dzibuti',
        ],
        'DZD' => [
            'DZD',
            'Ndina wa Alijeri',
        ],
        'EGP' => [
            'EGP',
            'Pauni wa Mushidi',
        ],
        'ERN' => [
            'ERN',
            'Nakfa wa Elitle',
        ],
        'ETB' => [
            'ETB',
            'Bira wa Etshiopi',
        ],
        'EUR' => [
            '€',
            'Iro',
        ],
        'GBP' => [
            '£',
            'Pauni wa Angeletele',
        ],
        'GHC' => [
            'GHC',
            'Sedi wa Ngana',
        ],
        'GMD' => [
            'GMD',
            'Ndalasi wa Ngambi',
        ],
        'GNS' => [
            'GNS',
            'Nfalanga wa Ngina',
        ],
        'INR' => [
            '₹',
            'Rupi wa Inde',
        ],
        'JPY' => [
            'JP¥',
            'Yeni wa Zapɔ',
        ],
        'KES' => [
            'KES',
            'Nshili wa Kenya',
        ],
        'KMF' => [
            'KMF',
            'Nfalanga wa Komoru',
        ],
        'LRD' => [
            'LRD',
            'Ndola wa Liberya',
        ],
        'LSL' => [
            'LSL',
            'Loti wa Lesoto',
        ],
        'LYD' => [
            'LYD',
            'Ndina wa Libi',
        ],
        'MAD' => [
            'MAD',
            'Ndiriha wa Maroke',
        ],
        'MGA' => [
            'MGA',
            'Nfalanga wa Madagasikare',
        ],
        'MRO' => [
            'MRO',
            'Ugwiya wa Moritani (1973–2017)',
        ],
        'MRU' => [
            'MRU',
            'Ugwiya wa Moritani',
        ],
        'MUR' => [
            'MUR',
            'Rupia wa Morisi',
        ],
        'MWK' => [
            'MWK',
            'Kwasha wa Malawi',
        ],
        'MZM' => [
            'MZM',
            'Metikali wa Mozambiki',
        ],
        'NAD' => [
            'NAD',
            'Ndola wa Namibi',
        ],
        'NGN' => [
            'NGN',
            'Naira wa Nizerya',
        ],
        'RWF' => [
            'RWF',
            'Nfalanga wa Rwanda',
        ],
        'SAR' => [
            'SAR',
            'Riyale wa Alabu Nsawu',
        ],
        'SCR' => [
            'SCR',
            'Rupya wa Seshele',
        ],
        'SDG' => [
            'SDG',
            'Ndina wa Suda',
        ],
        'SDP' => [
            'SDP',
            'Pauni wa Suda',
        ],
        'SHP' => [
            'SHP',
            'Pauni wa Santu Elena',
        ],
        'SLE' => [
            'SLE',
            'Leone',
        ],
        'SLL' => [
            'SLL',
            'Leone (1964—2022)',
        ],
        'SOS' => [
            'SOS',
            'Nshili wa Somali',
        ],
        'STD' => [
            'STD',
            'Dobra wa Sao Tome ne Presipe (1977–2017)',
        ],
        'STN' => [
            'STN',
            'Dobra wa Sao Tome ne Presipe',
        ],
        'SZL' => [
            'SZL',
            'Lilangeni',
        ],
        'TND' => [
            'TND',
            'Ndina wa Tinizi',
        ],
        'TZS' => [
            'TZS',
            'Nshili wa Tanzani',
        ],
        'UGX' => [
            'UGX',
            'Nshili wa Uganda',
        ],
        'USD' => [
            'US$',
            'Ndola wa Ameriki',
        ],
        'XAF' => [
            'FCFA',
            'Nfalanga CFA BEAC',
        ],
        'XOF' => [
            'F CFA',
            'Nfalanga CFA BCEAO',
        ],
        'ZAR' => [
            'ZAR',
            'Rande wa Afrika wa Mwinshi',
        ],
        'ZMK' => [
            'ZMK',
            'Kwasha wa Zambi (1968–2012)',
        ],
        'ZMW' => [
            'ZMW',
            'Kwasha wa Zambi',
        ],
        'ZWD' => [
            'ZWD',
            'Ndola wa Zimbabwe',
        ],
    ],
];
