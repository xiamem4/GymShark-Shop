<?php

/*
 * This file is part of the Symfony package.
 *
 * (c) Fabien Potencier <fabien@symfony.com>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace Symfony\Component\Form\Test;

use Symfony\Component\Form\FormInterface as BaseFormInterface;

/**
 * @extends \Iterator<string, BaseFormInterface>
 */
interface FormInterface extends \Iterator, BaseFormInterface
{
}
